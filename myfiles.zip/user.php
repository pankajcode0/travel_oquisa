<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<title>Registration</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>

</script>
<script>
function validateForm() {
    var x = document.forms["myForm"]["contact"].value;
    if (x == "" || x.length != 10) {
        alert("contact must be filled out correctly in 10 digits ");
        return false;
    }
    if (isNaN(x)) {
      alert ("Contact is not a number ")
      return false;
    }
    var y = document.forms["myForm"]["date"].value;
    if (y == "") {
        alert("date must be filled out ");
        return false;
    }
    var z = document.forms["myForm"]["time"].value;
    if (z == "") {
        alert("time must be filled out ");
        return false;
    }
    
}
</script>


<link rel="stylesheet" href="style.css" />
</head>
<body>
<?php


session_start();
if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
  $name1=$_SESSION["name1"];
  $user_id=$_SESSION["user_id"];
} else {
  header( "Location:login.php" ); die;
}

?>

<div class='header'>
  <a href=''  color="red" class='logo'>Student Travel</a>
 
  <div class='header-right'>
    <a  href='index.php'>Home</a>
    <a href=''>About</a>
    <a class='active'href='user.php'>My Account</a>
    <a class=''href='logout.php'>Logout</a>
  </div>
  <a> welcome <?php echo "$name1";?></a>
</div>

<h2>Add new:</h2>
<form name="myForm" onsubmit="return validateForm()" method="post" action = "user.php" method = "post">

 select place:        
         <select name = 'places'>
            <option value = 'Palakkad railway station '>Palakkad Railway station</option>
            <option value = 'Coimbatore airport'>Coimbatore airport</option>
            <option value = 'Coimbator railway station'>Coimbatore railway station</option>
         </select>
 select date:
         <input type='date' name='date'>
select time:
        <input type='time' name='time'>
contact Number:
        <input type='int' name='contact'>         
         <input type = 'submit' value = 'Submit' />
      </form>



<h2>your travel chart:</h2>
<table id='t01'>
  <tr>
    <th>Name</th>
    <th>Contact</th>
    <th>Going to</th>
    <th>Date</th>
    <th>Time</th>
    <th>Delete Entry</th>
  </tr>
  
<?php
require('db.php');
      if (isset($_REQUEST['places'])){
        $place = stripslashes($_REQUEST['places']); // removes backslashes
        $place = mysqli_real_escape_string($con,$place); //escapes special characters in a string
        $date = stripslashes($_REQUEST['date']);
        $date = mysqli_real_escape_string($con,$date);
        $time = stripslashes($_REQUEST['time']);
        $time= mysqli_real_escape_string($con,$time);
        $contact = stripslashes($_REQUEST['contact']);
        $contact= mysqli_real_escape_string($con,$contact);
        $query = "INSERT into `chart` (chart_id,user_id,name,contact_no,place,date,time) VALUES (NULL,'$user_id','$name1','$contact','$place','$date','$time')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "success";
        }
        else{
            echo "fail";
        }
      }
      $sql = "SELECT * FROM chart WHERE user_id='$user_id'";
      $run_query = mysqli_query($con,$sql);

      if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$name1   = $row['name'];
			$contact1   = $row['contact_no'];
			$place1 = $row['place'];
			$date1 = $row['date'];
      $time1 = $row['time'];
      $chart_id1=$row['chart_id'];
      $_SESSION["chart_id1"] =$chart_id1;
			echo "<tr>
      <td>$name1</td>
      <td>$contact1</td>
      <td>$place1</td>
      <td>$date1</td>
      <td>$time1</td>
      <td><form action='delete.php' method='post'>        
      <input type = 'submit' name='chart_id' value = 'delete' />
   </form></td>    

    </tr>
			";
		}
    }
    echo"</table>";
     ?>
   <footer>
    <p>Powered by @oquisa.com</p>
  </footer> 

