<form action = "#" method = "post">

Name  :
<input type="text" id="name" name="name" placeholder="email"><br>

Email  :
<input type="text" id="email" name="email" placeholder="email"><br>

Password   :
<input type="password" id="password" name="password" placeholder="password"><br>

contact  :
<input type="text" id="contact" name="contact" placeholder="contact"><br>

      
         <input type = "submit" value = "Submit" />
      </form>
      <a href="login.php" >Login<a>
      </div>
      <?php