<?php
// Start the session
session_start();
require('db.php');
$name1=$_SESSION["name1"];
$user_id=$_SESSION["user_id"];
$chart_id=$_SESSION["chart_id1"];
$y=$_POST["chart_id"];
?>
<?php




echo "$chart_id";
echo "$name1";
echo "$y";

$query = "DELETE  FROM chart WHERE chart_id='$chart_id'";
$result = mysqli_query($con,$query);
        if($result){
          echo "success";
      }
      else{
          echo "fail";
      }
header( "Location:user.php" ); die;
?>